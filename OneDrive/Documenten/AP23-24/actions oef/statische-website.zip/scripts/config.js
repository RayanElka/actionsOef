var CONFIG = {};
CONFIG.BASE_NODE_SERVER_STR = "https://<cloudfront-domain>";
//CONFIG.COGNITO_DOMAIN_STR = "<cognito-domain>";
//CONFIG.COGNITO_USER_POOL_ID_STR = "<cognito-user-pool-id>";
//CONFIG.COGNITO_USER_POOL_CLIENT_ID_STR = "<cognito-app-client-id>";
//CONFIG.CLOUDFRONT_DISTRO_STR = "<cloudfront-distribution>";
//CONFIG.COGNITO_IDENTITY_POOL_ID_STR = "<cognito-identity-pool-id>";

